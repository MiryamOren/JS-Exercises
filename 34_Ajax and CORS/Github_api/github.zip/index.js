const API = 'https://api.github.com/users/';
// const API = '#';
const alreadyFetchedUsers = {};

function display(userObject) {
  const initialCard = document.querySelector('.initial-card');
  const errorCard = document.querySelector('.error-card');
  const card = document.querySelector('.user-card');
  const img = document.querySelector('.user-card__image');
  const name = document.querySelector('a');
  const repos = document.querySelector('.user-card__repos');
  img.style.backgroundImage = `url(${userObject.avatar_url})`;
  name.innerHTML = userObject.name || userObject.login;
  name.setAttribute('href', `${userObject.html_url}`);
  repos.innerHTML = `Number of Public Repo's: ${userObject.public_repos}`;

  errorCard.style.display = 'none';
  initialCard.style.display = 'none';
  card.style.display = 'block';
}
function diplayError(message) {
  const initialCard = document.querySelector('.initial-card');
  const userCard = document.querySelector('.user-card');
  const errorCard = document.querySelector('.error-card');

  initialCard.style.display = 'none';
  userCard.style.display = 'none';

  errorCard.innerHTML = message;
  errorCard.style.display = 'block';
}
async function fetchUser(userName) {
  fetch(API + userName)
    .then((response) => response.json())
    .then((userObject) => {
      if (userObject.message === 'Not Found') {
        diplayError(
          `No such user ${userName}<br><br> please check your spelling and try again`
        );
      } else {
        alreadyFetchedUsers[userName] = userObject;
        display(userObject);
      }
    })
    .catch((error) => {
      console.log(error);
      diplayError(
        `Oops, there was a problem.<br> please try again in a few minutes`
      );
    });
}
function submitEvent() {
  const userName = document.querySelector('input').value;
  document.querySelector('input').value = '';
  if (alreadyFetchedUsers.hasOwnProperty(userName)) {
    display(alreadyFetchedUsers[userName]);
  } else {
    fetchUser(userName);
  }
}

const submitBtn = document.querySelector('button');
submitBtn.addEventListener('click', submitEvent);
const input = document.querySelector('input');
input.addEventListener('keyup', function (event) {
  if (event.key === 'Enter') {
    submitEvent();
  }
});
